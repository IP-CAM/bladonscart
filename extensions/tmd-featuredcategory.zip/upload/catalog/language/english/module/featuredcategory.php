<?php
// Heading 
$_['heading_title'] = 'Featured Category';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>