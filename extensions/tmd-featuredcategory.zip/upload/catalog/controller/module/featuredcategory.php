<?php
class ControllerModulefeaturedcategory extends Controller {
		public function index($setting) {
		
		$this->load->language('module/featuredcategory'); 

      	$data['heading_title'] = $this->language->get('heading_title');
		
		$data['button_cart'] = $this->language->get('button_cart');
		
		$this->load->model('catalog/category'); 
		
		$this->load->model('tool/image');

		$data['categorys'] = array();
		

		$categorys = explode(',', $this->config->get('featuredcategory_category'));	
			
		if (empty($setting['limit'])) {
			$setting['limit'] = 5;
		}
		
		$categorys = array_slice($categorys, 0, (int)$setting['limit']);
		
		foreach ($categorys as $category_id) {
			$category_info = $this->model_catalog_category->getcategory($category_id);
			
			if ($category_info) {
				if ($category_info['image']) {
					$image = $this->model_tool_image->resize($category_info['image'], $setting['width'], $setting['height']);
				} else {
					$image = false;
				}
					$data['categorys'][] = array(
					'category_id' => $category_info['category_id'],
					'thumb'   	 => $image,
					'name'    	 => $category_info['name'],
					'href'    	 => $this->url->link('product/category', 'path=' . $category_info['category_id'])
				);
			}
		}

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/featuredcategory.tpl')) {
				return $this->load->view($this->config->get('config_template') . '/template/module/featuredcategory.tpl', $data);
			} else {
				return $this->load->view('default/template/module/featuredcategory.tpl', $data);
			}
	}
}
?>